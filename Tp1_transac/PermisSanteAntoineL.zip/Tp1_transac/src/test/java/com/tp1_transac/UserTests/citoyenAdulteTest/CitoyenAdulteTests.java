package com.tp1_transac.UserTests.citoyenAdulteTest;

import com.tp1_transac.repositories.citoyen.CitoyenRepository;
import com.tp1_transac.repositories.permis.PermisRepository;
import com.tp1_transac.services.citoyen.CitoyenServices;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;


@DataJpaTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CitoyenAdulteTests {

    public final String citoyenAdulteUserName = "AntoineZolos";
    public final String citoyenAdultePassword = "Antoine1234";
    public final String citoyenAdulteNumSocial = "123543";
    public final String citoyenAdulteNom = "Antoine";
    public final String citoyenAdultePrenom = "Lamoureux";
    public final String citoyenAdulteSexe = "Homme";
    public final Integer citoyenAdulteAge = 30;
    public final String citoyenAdulteEmail = "antoine3wls@gmail.com";
    public final String citoyenNumTelephone = "514-555-333";
    public final String citoyenAdulteTypePermisDemande = "Vaccin";


    @Test
    void contextLoads() {
    }
    @Autowired
    public CitoyenRepository citoyenRepository;
    @Autowired
    public PermisRepository permisRepository;

    @Autowired
    public CitoyenServices citoyenServices;


    @Test
    @Disabled
    public void testFindAllCiotyenAdulte(){
        Assertions.assertEquals(citoyenRepository.findAll().size(), 1);
    }


    @Test
    @Disabled
    public void testFindCitoyenAdulteByUserName() {
        Assertions.assertNotNull(citoyenRepository.findCitoyenAdulteByUsernameAndPassword("Antoine", "Antoine1234"));
    }

    @Test
    public void testInscriptionCitoyenAdulte() {
        Assertions.assertTrue(citoyenServices.inscriptionCitoyenAdulte(citoyenAdulteUserName, citoyenAdultePassword, citoyenAdulteNumSocial, citoyenAdulteNom, citoyenAdultePrenom, citoyenAdulteSexe, citoyenAdulteAge, citoyenAdulteEmail, citoyenNumTelephone, citoyenAdulteTypePermisDemande));
    }

    @Test
    public void testLoginCitoyenAdulte(){
        Assertions.assertTrue(citoyenServices.login(citoyenAdulteUserName, citoyenAdultePassword));
    }
}
