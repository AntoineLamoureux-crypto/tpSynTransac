package com.tp1_transac.UserTests.citoyenEnfantTest;

import com.tp1_transac.models.permis.Permis;
import com.tp1_transac.models.user.citoyen.CitoyenEnfant;
import com.tp1_transac.repositories.citoyen.CitoyenEnfantRepository;
import com.tp1_transac.repositories.permis.PermisRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CitoyenEnfantTests {

    @Autowired
    private CitoyenEnfantRepository citoyenEnfantRepository;
    @Autowired
    private PermisRepository permisRepository;

    @BeforeAll
    public void insertDataCitoyenEnfant() {

        CitoyenEnfant citoyenEnfant = new CitoyenEnfant();
        Permis p2 = new Permis();

        p2.setTypePermis("VACCIN");

        citoyenEnfant.setUsername("AntoineEnfant"); citoyenEnfant.setPassword("Young1234"); citoyenEnfant.setPermis(p2);

        permisRepository.save(p2);
        citoyenEnfantRepository.save(citoyenEnfant);
    }
}
