package com.tp1_transac.repositories.ministere;

import com.tp1_transac.models.ministere.Ministere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitoyenMinistereRepository extends JpaRepository<Ministere, Integer> {

    public Ministere findMinistereByNumSocial(String numSocial);
}
