package com.tp1_transac.models.ministere;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Data
public class Ministere implements Serializable {

    @Id
    @GeneratedValue
    private Integer id;
    @NotNull
    private String nom;

    @NotNull
    private String prenom;

    @NotNull
    private String numSocial;

    @NotNull
    private boolean isNumSocialValid;

}
