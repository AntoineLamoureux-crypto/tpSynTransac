package com.tp1_transac.repositories.citoyen;
import com.tp1_transac.models.user.citoyen.CitoyenEnfant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CitoyenEnfantRepository extends JpaRepository<CitoyenEnfant, Integer> {
    public CitoyenEnfant findCitoyenEnfantByUsernameIgnoreCaseAndPassword(String input1, String input2);

    public CitoyenEnfant findCitoyenEnfantByUsernameAndPassword(String login, String password);

    public CitoyenEnfant findCitoyenEnfantByUsername(String login);
}
