package com.tp1_transac.services.admin;

import org.springframework.stereotype.Service;

@Service
public class AdminServices {
}
