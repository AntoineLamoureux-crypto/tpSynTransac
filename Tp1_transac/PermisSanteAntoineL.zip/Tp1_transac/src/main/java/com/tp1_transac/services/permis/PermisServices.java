package com.tp1_transac.services.permis;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.tp1_transac.models.permis.Permis;
import com.tp1_transac.models.user.citoyen.CitoyenAdulte;
import com.tp1_transac.models.user.citoyen.CitoyenEnfant;
import com.tp1_transac.repositories.citoyen.CitoyenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.internet.MimeMessage;
import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

public class PermisServices {

    final private String filePathQrAdulte = "c:/WEB/420/citoyen/adulte/qr/";
    final private String filePathQrEnfant = "c:/WEB/420/citoyen/enfant/qr/";

    final private String filePathPdfAdulte = "c:/WEB/420/citoyen/adulte/pdf/";
    final private String filePathPdfEnfant = "c:/WEB/420/citoyen/enfant/pdf/";

    @Autowired
    CitoyenRepository citoyenRepository;

    @Autowired
    static JavaMailSender mailSender;

    public void createNewQRAdulte(CitoyenAdulte citoyenAdulte) throws Exception {
        Path path = FileSystems.getDefault().getPath(filePathQrAdulte + citoyenAdulte.getPermis().getTypePermis() + citoyenAdulte.getNom() + ".PNG");
        Files.createDirectories(path);
        QRCodeWriter qr = new QRCodeWriter();
        MatrixToImageWriter.writeToPath(qr.encode(citoyenAdulte.toString(), BarcodeFormat.QR_CODE, 300, 300), "PNG", path);

        createNewPDFAdulte(citoyenAdulte);
    }

    public void createNewQREnfant(CitoyenEnfant citoyenEnfant) throws Exception {
        Path path = FileSystems.getDefault().getPath(filePathQrEnfant +  citoyenEnfant.getPermis().getTypePermis() + citoyenEnfant.getNom() + ".PNG");
        Files.createDirectories(path);
        QRCodeWriter qr = new QRCodeWriter();
        MatrixToImageWriter.writeToPath(qr.encode(citoyenEnfant.toString(), BarcodeFormat.QR_CODE, 300, 300), "PNG", path);

        createNewPDFEnfant(citoyenEnfant);
    }

    public void createNewPDFAdulte(CitoyenAdulte citoyenAdulte) throws Exception{
        PdfWriter writer = new PdfWriter(filePathPdfAdulte + citoyenAdulte.getPermis().getTypePermis() + citoyenAdulte.getNom() + ".pdf");
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        Image image = new Image(ImageDataFactory.create(filePathQrAdulte + citoyenAdulte.getPermis().getTypePermis() + citoyenAdulte.getNom() + ".PNG"));
        Paragraph p = new Paragraph("Bonjour toi" + citoyenAdulte.getNom()).add("Voici ton code permis de " + citoyenAdulte.getPermis().getTypePermis()).add(image);
        document.add(p);
        document.close();

        sendEmail(citoyenAdulte.getEmail(), "Permis santé", document.toString(), "Adulte");

    }
    public void createNewPDFEnfant(CitoyenEnfant citoyenEnfant) throws Exception{
        PdfWriter writer = new PdfWriter(filePathPdfEnfant + citoyenEnfant.getPermis().getTypePermis() + citoyenEnfant.getNom() + ".pdf");
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        Image image = new Image(ImageDataFactory.create(filePathQrEnfant +  citoyenEnfant.getPermis().getTypePermis() + citoyenEnfant.getNom() + ".PNG"));
        Paragraph p = new Paragraph("Bonjour " + citoyenEnfant.getNom()).add("Voici ton code permis de " + citoyenEnfant.getPermis().getTypePermis()).add(image);
        document.add(p);
        document.close();

        CitoyenAdulte citoyenAdulte = citoyenRepository.findCitoyenAdulteByUsernameAndPassword(citoyenEnfant.getUsername(), citoyenEnfant.getPassword());

        sendEmail(citoyenAdulte.getEmail(), "Permis santé", document.toString(), "Enfant");
    }

    public void sendEmail(String mailTo, String subject, String body, String acteur) throws Exception {

        String filePathQr = "";
        String filePathPdf = "";

        if (acteur.equals("Adulte")) {
            filePathQr = filePathQrAdulte;
            filePathPdf = filePathPdfAdulte;
        }
        else {
            filePathQr = filePathQrEnfant;
            filePathPdf = filePathPdfEnfant;
        }
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(mailTo);
        helper.setSubject(subject);
        helper.setText(body);
        helper.addAttachment("QR CODE", new File(filePathQr));
        helper.addAttachment("QR PDF", new File(filePathPdf));

        mailSender.send(message);
    }

    public void renewQREnfant(CitoyenEnfant citoyenEnfant) {

        Permis permis = citoyenEnfant.getPermis();
        if (permis.getTypePermis().equals("VA")) {
            permis.setDatePermis(LocalDate.now());
            permis.setDateExpiration(LocalDate.now().plusMonths(6));
        }
        else {
            permis.setDatePermisTest(LocalDate.now());
            permis.setDateExpirationTest(LocalDate.now().plusDays(15));
        }
    }

    public void renewQrAdulte(CitoyenAdulte citoyenAdulte) {
        Permis permis = citoyenAdulte.getPermis();
        if (permis.getTypePermis().equals("VA")) {
            permis.setDatePermis(LocalDate.now());
            permis.setDateExpiration(LocalDate.now().plusMonths(6));
        }
        else {
            permis.setDatePermisTest(LocalDate.now());
            permis.setDateExpirationTest(LocalDate.now().plusDays(15));
        }
    }
}
