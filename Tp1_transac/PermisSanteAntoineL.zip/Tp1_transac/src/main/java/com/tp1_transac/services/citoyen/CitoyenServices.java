package com.tp1_transac.services.citoyen;

import com.tp1_transac.models.permis.Permis;
import com.tp1_transac.models.user.citoyen.CitoyenAdulte;
import com.tp1_transac.models.user.citoyen.CitoyenEnfant;
import com.tp1_transac.repositories.citoyen.CitoyenEnfantRepository;
import com.tp1_transac.repositories.citoyen.CitoyenRepository;
import com.tp1_transac.repositories.ministere.CitoyenMinistereRepository;
import com.tp1_transac.repositories.permis.PermisRepository;
import com.tp1_transac.services.permis.PermisServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class CitoyenServices {

    @Autowired
    private CitoyenRepository citoyenRepository;

    @Autowired
    private CitoyenEnfantRepository citoyenEnfantRepository;

    @Autowired
    private PermisRepository permisRepository;

    @Autowired
    private CitoyenMinistereRepository citoyenMinistereRepository;

    private PermisServices permisServices;


    public boolean isLoginExist(String log, String mp){
        return citoyenRepository.findCitoyenAdulteByUsernameIgnoreCaseAndPassword(log, mp) != null;
    }


    public boolean login(String log, String mp) {
        return isLoginExist(log, mp);
    }


    @Transactional
    public boolean inscriptionCitoyenAdulte(String userName, String password, String num_social, String nom, String prenom, String sexe, int age, String email, String num_telephone, String typePermisDemande){

        //Vérifier si le nom et le prenom = au bon numero d'assurance social dans la bd (entity Ministere)

        CitoyenAdulte citoyenAdulte = new CitoyenAdulte();

        citoyenAdulte.setUsername(userName);
        citoyenAdulte.setPassword(password);
        citoyenAdulte.setNum_social(num_social);
        citoyenAdulte.setSexe(sexe);
        citoyenAdulte.setAge(age);
        citoyenAdulte.setNum_telphone(num_telephone);
        citoyenAdulte.setEmail(email);
        citoyenAdulte.setNom(nom);
        citoyenAdulte.setPrenom(prenom);

        Permis permis = new Permis();
        permis.setPermisEnfant(false);
        if (typePermisDemande.toLowerCase(Locale.ROOT).equals("vaccin")) {
            permis.setTypePermis("VA");
            permis.setDatePermis(LocalDate.now());
            permis.setDateExpiration(LocalDate.now().plusMonths(6));
        }
        else {
            permis.setTypePermis("TE");
            permis.setDatePermisTest(LocalDate.now());
            permis.setDateExpirationTest(LocalDate.now().plusDays(15));
        }
        permisRepository.save(permis);
        citoyenAdulte.setPermis(permis);
        citoyenRepository.save(citoyenAdulte);
        try {
            permisServices.createNewQRAdulte(citoyenAdulte);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean inscriptionCitoyenEnfant(String num_social, String nom, String prenom, String sexe, int age, String userNameParent, String passwordParent, String typePermisDemande, String emailParent) {

        if (citoyenRepository.findCitoyenAdulteByUsernameAndPassword(userNameParent, passwordParent) == null) {
            return false;
        }
        else {
            CitoyenEnfant citoyenEnfant = new CitoyenEnfant();
            citoyenEnfant.setNum_social(num_social);
            citoyenEnfant.setSexe(sexe);
            citoyenEnfant.setAge(age);
            citoyenEnfant.setNom(nom);
            citoyenEnfant.setPrenom(prenom);

            Permis permis = new Permis();
            permis.setPermisEnfant(true);
            if (typePermisDemande.toLowerCase(Locale.ROOT).equals("vaccin")) {
                permis.setTypePermis("VA");
                permis.setDatePermis(LocalDate.now());
                permis.setDateExpiration(LocalDate.now().plusMonths(6));
            }
            else {
                permis.setTypePermis("TE");
                permis.setDatePermisTest(LocalDate.now());
                permis.setDateExpirationTest(LocalDate.now().plusDays(15));
            }
            citoyenEnfant.setPermis(permis);

            CitoyenAdulte citoyenAdulte = citoyenRepository.findCitoyenAdulteByUsername(citoyenEnfant.getUsername());
            List<CitoyenEnfant> citoyenEnfantList;
            if (citoyenAdulte.getCitoyenEnfantList() == null) {
                citoyenEnfantList = new ArrayList<>();
                citoyenAdulte.setCitoyenEnfantList(citoyenEnfantList);
                citoyenEnfantList.add(citoyenEnfant);
            }
            else {
                 citoyenAdulte.getCitoyenEnfantList().add(citoyenEnfant);
            }

            permisRepository.save(permis);
            citoyenEnfantRepository.save(citoyenEnfant);
            try {
                permisServices.createNewQREnfant(citoyenEnfant);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
    }
}
