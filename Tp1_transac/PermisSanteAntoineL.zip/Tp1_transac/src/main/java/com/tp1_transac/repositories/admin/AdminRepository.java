package com.tp1_transac.repositories.admin;

import com.tp1_transac.models.user.admin.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
}
