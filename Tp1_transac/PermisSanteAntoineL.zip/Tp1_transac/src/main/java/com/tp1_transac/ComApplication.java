package com.tp1_transac;
import com.tp1_transac.models.user.citoyen.CitoyenAdulte;
import com.tp1_transac.services.citoyen.CitoyenServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComApplication implements CommandLineRunner {

    @Autowired
    CitoyenServices citoyenServices;

    public static void main(String[] args) {
        SpringApplication.run(ComApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        CitoyenAdulte citoyenAdulte = new CitoyenAdulte();
        citoyenAdulte.setSexe("Homme");
        citoyenAdulte.setNum_social("1232435");
        citoyenAdulte.setPrenom("Lamoureux");
        citoyenAdulte.setNom("Antoine");
        citoyenAdulte.setPassword("Antoine1234");
        citoyenAdulte.setEmail("antoine@gmail.com");
        citoyenAdulte.setAge(20);

        String typePermis = "VaCcin";

        System.out.println(citoyenServices.inscriptionCitoyenAdulte(citoyenAdulte.getUsername(), citoyenAdulte.getPassword(), citoyenAdulte.getNum_social(), citoyenAdulte.getNom(), citoyenAdulte.getPrenom(), citoyenAdulte.getSexe(), citoyenAdulte.getAge(), citoyenAdulte.getEmail(), citoyenAdulte.getNum_telphone(), typePermis));
    }
}
