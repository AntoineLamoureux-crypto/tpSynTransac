package com.tp1_transac.models.user.citoyen;

import com.tp1_transac.models.permis.Permis;
import com.tp1_transac.models.user.User;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Data
public class CitoyenEnfant extends User implements Serializable {

    @GeneratedValue
    @NotNull
    private String num_social;

    @NotNull
    private String nom;

    @NotNull
    private String prenom;

    @NotNull
    private String sexe;

    @NotNull
    private int age;

    @OneToOne
    @JoinColumn()
    private Permis permis;
}
