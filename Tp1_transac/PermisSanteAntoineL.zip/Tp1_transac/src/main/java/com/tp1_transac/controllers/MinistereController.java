package com.tp1_transac.controllers;

import com.tp1_transac.repositories.citoyen.CitoyenEnfantRepository;
import com.tp1_transac.repositories.citoyen.CitoyenRepository;
import com.tp1_transac.repositories.ministere.CitoyenMinistereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MinistereController {

    @Autowired
    CitoyenRepository citoyenRepository;

    @Autowired
    CitoyenMinistereRepository citoyenMinistereRepository;

    @Autowired
    CitoyenEnfantRepository citoyenEnfantRepository;

    @GetMapping()
    public boolean checkCitoyenValidity(String numSocial){
        return citoyenMinistereRepository.findMinistereByNumSocial(numSocial).isNumSocialValid();
    }
}
