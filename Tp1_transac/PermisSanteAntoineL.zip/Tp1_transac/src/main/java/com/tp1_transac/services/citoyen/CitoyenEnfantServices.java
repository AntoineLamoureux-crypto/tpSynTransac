package com.tp1_transac.services.citoyen;

import org.springframework.stereotype.Service;

@Service
public class CitoyenEnfantServices {
}
