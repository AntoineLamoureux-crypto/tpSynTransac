package com.tp1_transac.repositories.citoyen;

import com.tp1_transac.models.user.citoyen.CitoyenAdulte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitoyenRepository extends JpaRepository<CitoyenAdulte, Integer> {

    public CitoyenAdulte findCitoyenAdulteByUsernameAndPassword(String input1, String input2);

    public CitoyenAdulte findCitoyenAdulteByUsernameIgnoreCaseAndPassword(String login, String password);

    public CitoyenAdulte findCitoyenAdulteByUsername(String login);

}
