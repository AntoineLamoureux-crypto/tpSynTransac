package com.tp1_transac.models.permis;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Data
public class Permis implements Serializable {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @NotNull
    private String typePermis;

    private boolean permisEnfant;

    private LocalDate datePermis;

    private LocalDate dateExpiration;

    private LocalDate datePermisTest;

    private LocalDate dateExpirationTest;

    private String region;
}
