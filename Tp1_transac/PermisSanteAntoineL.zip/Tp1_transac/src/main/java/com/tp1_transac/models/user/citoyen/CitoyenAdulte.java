package com.tp1_transac.models.user.citoyen;

import com.tp1_transac.models.permis.Permis;
import com.tp1_transac.models.user.User;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Data
@Entity
public class CitoyenAdulte extends User implements Serializable {

    @GeneratedValue
    @NotNull
    private String num_social;
    @NotNull
    private String nom;
    @NotNull
    private String prenom;
    @NotNull
    private String sexe;
    @NotNull
    private int age;
    @NotNull
    private String email;
    @NotNull
    private String num_telphone;

    @OneToOne
    @JoinColumn()
    private Permis permis;

    @OneToMany
    @JoinColumn
    private List<CitoyenEnfant> citoyenEnfantList;

}
